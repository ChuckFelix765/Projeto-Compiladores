//MainToken.java
public class MainToken{
	public static void main(String[] args){
		Token t1 = new Token("ID", "resultado");
		Token t2 = new Token("NUM", "234");

		System.out.println(t1);
		System.out.println(t2);
	}
}