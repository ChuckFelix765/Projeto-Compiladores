//Token.java
public class Token{
	private String tipo;
	private String lexema;

	public Token(String tipo, String lexema){
		this.lexema = lexema;
		this.tipo = tipo;
	}

	public String getLexema(){
		return lexema;
	}

	public String getTipo(){
		return tipo;
	}

	@Override
	public String toString(){
		return "< " + tipo + ", " + lexema + " >";
	}

}